#Exercise 4, chapter 1 (Zelle 2017, Python Programming: An Introduction to Computer Science)

def main():
    print("This program illustrates a chaotic function")
    x = eval(input("Enter a number between 0 and 1: "))
    for i in range(20):
        x = 2.0 * x * (1-x)
        print(x)

main()