#Exercise 7, chapter 1 (Zelle 2017, Python Programming: An Introduction to Computer Science)

def main():
    print("This program illustrates a chaotic function")
    x = eval(input("Enter a number between 0 and 1: "))
    x_orig = x
    y = eval(input("Enter a second number between 0 and 1: "))
    y_orig = y
    print(f"Input values: {x_orig} and {y_orig} ")
    for i in range(10):
        x = 3.9 * x  * (1-x)
        y = 3.9 * y  * (1-y)
        print(f"{x:.3f}", f"{y:.3f}")
    
main()