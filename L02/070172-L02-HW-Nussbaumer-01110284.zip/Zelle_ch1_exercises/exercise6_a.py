#Exercise 6a, chapter 1 (Zelle 2017, Python Programming: An Introduction to Computer Science)

def main():
    print("This program illustrates a chaotic function")
    x = eval(input("Enter a number between 0 and 1: "))
    for i in range(100):
        x = 3.9 * x * (1-x)
        print(x)

main()

'''
The different versions 6a, 6b, 6c show very similar results for the first couple of iterations (except for minor differences in
decimal places), but the more often the calculation is repeated the results change from version to version significantly
'''