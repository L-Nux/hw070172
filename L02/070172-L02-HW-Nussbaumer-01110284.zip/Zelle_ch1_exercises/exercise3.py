#Exercise 3, chapter 1 (Zelle 2017, Python Programming: An Introduction to Computer Science)

def main():
    print("This program illustrates a chaotic function")
    x = eval(input("Enter a number between 0 and 1: "))
    for i in range(10):
        x = 2.0 * x * (1-x)
        print(x)

main()

'''
with the changed value (2.0) the result becomes a constant value after a few iterations.
whereas with original program (3.9) in all ten iterations a different value is the result.
'''